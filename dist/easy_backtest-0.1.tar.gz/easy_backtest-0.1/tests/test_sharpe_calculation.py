"""
Test Sharpe ratio calculation across different timeframes to ensure proper annualization.
"""
import pytest
import pandas as pd
import numpy as np
from datetime import datetime
from easy_backtest.backtest_engine import BacktestEngine


class SimpleStrategy(BacktestEngine):
    """Simple moving average crossover strategy for testing"""

    def preprocess_data(self):
        self.data_stream['ma_short'] = self.data_stream['close'].rolling(window=5).mean()
        self.data_stream['ma_long'] = self.data_stream['close'].rolling(window=20).mean()
        return self.data_stream

    def strategy(self, row):
        long_position = self.position_book.get_position_by_tag("long")

        # Entry logic
        if row.ma_short > row.ma_long and not long_position:
            tp = row.close * 1.02
            sl = row.close * 0.98
            qty = 1.0
            self.position_book.open_long_position(
                quantity=qty,
                open_price=row.close,
                tag="long",
                tp=tp,
                sl=sl,
                open_time=row.Index
            )

        # Exit logic
        elif row.ma_short < row.ma_long and long_position:
            self.position_book.close_position(
                tag="long",
                close_price=row.close,
                close_time=row.Index
            )


def generate_synthetic_data(start_date, periods, freq_minutes):
    """
    Generate synthetic OHLCV data for testing.

    Args:
        start_date: Starting datetime
        periods: Number of periods to generate
        freq_minutes: Frequency in minutes (e.g., 1, 5, 15, 60, 1440)

    Returns:
        DataFrame with OHLCV data
    """
    # Create datetime index
    dates = pd.date_range(start=start_date, periods=periods, freq=f'{freq_minutes}min')

    # Generate synthetic price data with some trend and volatility
    np.random.seed(42)  # For reproducibility
    base_price = 100.0
    returns = np.random.normal(0.0001, 0.02, periods)  # Small positive drift
    prices = base_price * np.exp(np.cumsum(returns))

    # Create OHLCV data
    data = pd.DataFrame({
        'open': prices,
        'high': prices * (1 + np.random.uniform(0, 0.01, periods)),
        'low': prices * (1 - np.random.uniform(0, 0.01, periods)),
        'close': prices * (1 + np.random.normal(0, 0.005, periods)),
        'volume': np.random.uniform(100, 1000, periods)
    }, index=dates)

    return data


def test_periods_per_year_inference_1min():
    """Test that 1-minute data is correctly identified"""
    data = generate_synthetic_data(datetime(2024, 1, 1), 1440, 1)  # 1 day of 1-min data
    engine = SimpleStrategy(commission=0.001, portfolio_size=10000)
    engine.add_data_stream(data)

    inferred = engine._infer_periods_per_year()
    expected = int(365.25 * 24 * 60)  # 525,960 periods per year

    # Allow 1% tolerance due to rounding
    assert abs(inferred - expected) / expected < 0.01, f"Expected ~{expected}, got {inferred}"


def test_periods_per_year_inference_5min():
    """Test that 5-minute data is correctly identified"""
    data = generate_synthetic_data(datetime(2024, 1, 1), 288, 5)  # 1 day of 5-min data
    engine = SimpleStrategy(commission=0.001, portfolio_size=10000)
    engine.add_data_stream(data)

    inferred = engine._infer_periods_per_year()
    expected = int(365.25 * 24 * 12)  # 105,192 periods per year

    assert abs(inferred - expected) / expected < 0.01, f"Expected ~{expected}, got {inferred}"


def test_periods_per_year_inference_15min():
    """Test that 15-minute data is correctly identified"""
    data = generate_synthetic_data(datetime(2024, 1, 1), 96, 15)  # 1 day of 15-min data
    engine = SimpleStrategy(commission=0.001, portfolio_size=10000)
    engine.add_data_stream(data)

    inferred = engine._infer_periods_per_year()
    expected = int(365.25 * 24 * 4)  # 35,064 periods per year

    assert abs(inferred - expected) / expected < 0.01, f"Expected ~{expected}, got {inferred}"


def test_periods_per_year_inference_1hour():
    """Test that 1-hour data is correctly identified"""
    data = generate_synthetic_data(datetime(2024, 1, 1), 24, 60)  # 1 day of 1-hour data
    engine = SimpleStrategy(commission=0.001, portfolio_size=10000)
    engine.add_data_stream(data)

    inferred = engine._infer_periods_per_year()
    expected = int(365.25 * 24)  # 8,766 periods per year

    assert abs(inferred - expected) / expected < 0.01, f"Expected ~{expected}, got {inferred}"


def test_periods_per_year_inference_1day():
    """Test that daily data is correctly identified"""
    data = generate_synthetic_data(datetime(2024, 1, 1), 30, 1440)  # 30 days of daily data
    engine = SimpleStrategy(commission=0.001, portfolio_size=10000)
    engine.add_data_stream(data)

    inferred = engine._infer_periods_per_year()
    expected = 365

    assert abs(inferred - expected) / expected < 0.01, f"Expected ~{expected}, got {inferred}"


def test_sharpe_ratio_not_nan():
    """Test that Sharpe ratio is calculated and not NaN"""
    data = generate_synthetic_data(datetime(2024, 1, 1), 720, 60)  # 30 days of hourly data
    engine = SimpleStrategy(commission=0.001, portfolio_size=10000)
    engine.add_data_stream(data)
    engine.run()

    stats = engine.get_trading_stats()

    # Sharpe ratio should be a number (not NaN or inf)
    assert isinstance(stats['sharpe_ratio'], (int, float))
    assert not np.isnan(stats['sharpe_ratio'])
    assert not np.isinf(stats['sharpe_ratio'])


def test_sharpe_ratio_with_trades():
    """Test that Sharpe ratio is calculated when there are trades"""
    data = generate_synthetic_data(datetime(2024, 1, 1), 720, 60)  # 30 days of hourly data
    engine = SimpleStrategy(commission=0.001, portfolio_size=10000)
    engine.add_data_stream(data)
    engine.run()

    stats = engine.get_trading_stats()

    # If there are trades, sharpe ratio should be calculated
    if stats['total_trades'] > 1:
        # Sharpe ratio should be within a reasonable range for a trading strategy
        # (typically between -3 and 3 for most strategies, can be higher for very good ones)
        assert -10 < stats['sharpe_ratio'] < 10, f"Sharpe ratio {stats['sharpe_ratio']} seems unrealistic"


def test_returns_calculation():
    """Test that returns are properly calculated relative to portfolio value"""
    data = generate_synthetic_data(datetime(2024, 1, 1), 720, 60)
    engine = SimpleStrategy(commission=0.001, portfolio_size=10000)
    engine.add_data_stream(data)
    engine.run()

    trade_history_df = engine.get_trade_history().to_dataframe()

    if len(trade_history_df) > 0:
        # First trade's return should be profit / initial_portfolio
        first_profit = trade_history_df.iloc[0]['profit']
        expected_first_return = first_profit / 10000

        # Calculate what the stats method would compute
        portfolio_before = 10000
        actual_return = first_profit / portfolio_before

        assert abs(actual_return - expected_first_return) < 1e-6


def test_backtest_duration_calculation():
    """Test that backtest duration is based on calendar time, not trade duration"""
    # Generate 7 days of hourly data
    data = generate_synthetic_data(datetime(2024, 1, 1), 24*7, 60)
    engine = SimpleStrategy(commission=0.001, portfolio_size=10000)
    engine.add_data_stream(data)
    engine.run()

    trade_history_df = engine.get_trade_history().to_dataframe()

    if len(trade_history_df) > 1:
        # Calculate backtest duration from trade history
        backtest_start = pd.to_datetime(trade_history_df['open_time'].min())
        backtest_end = pd.to_datetime(trade_history_df['close_time'].max())
        backtest_duration_days = (backtest_end - backtest_start).total_seconds() / (24 * 60 * 60)

        # Should be less than 7 days (strategy needs warmup period for MAs)
        # but more than 1 day (should have some trading activity)
        assert 1 < backtest_duration_days < 7, f"Backtest duration {backtest_duration_days} days seems wrong"


@pytest.mark.parametrize("freq_minutes,freq_name", [
    (5, "5-minute"),
    (15, "15-minute"),
    (60, "1-hour"),
    (240, "4-hour"),
])
def test_multiple_timeframes(freq_minutes, freq_name):
    """Test that backtests work correctly across multiple timeframes"""
    # Generate 30 days worth of data
    periods_per_day = (24 * 60) // freq_minutes
    total_periods = periods_per_day * 30

    data = generate_synthetic_data(datetime(2024, 1, 1), total_periods, freq_minutes)
    engine = SimpleStrategy(commission=0.001, portfolio_size=10000)
    engine.add_data_stream(data)

    # Test inference
    inferred = engine._infer_periods_per_year()
    expected = int((365.25 * 24 * 60) / freq_minutes)

    assert abs(inferred - expected) / expected < 0.01, \
        f"{freq_name}: Expected ~{expected} periods/year, got {inferred}"

    # Run backtest
    engine.run()
    stats = engine.get_trading_stats()

    # Basic sanity checks
    assert stats['total_trades'] >= 0
    assert not np.isnan(stats['sharpe_ratio'])
    assert not np.isinf(stats['sharpe_ratio']) or stats['sharpe_ratio'] == 0


def test_empty_trade_history():
    """Test that Sharpe ratio handles empty trade history gracefully"""
    data = generate_synthetic_data(datetime(2024, 1, 1), 100, 60)

    # Strategy that never trades
    class NoTradeStrategy(BacktestEngine):
        def strategy(self, row):
            pass  # Never open any positions

    engine = NoTradeStrategy(commission=0.001, portfolio_size=10000)
    engine.add_data_stream(data)
    engine.run()

    stats = engine.get_trading_stats()

    assert stats['sharpe_ratio'] == 0.0
    assert stats['total_trades'] == 0


def test_single_trade():
    """Test that Sharpe ratio handles single trade case"""
    data = generate_synthetic_data(datetime(2024, 1, 1), 50, 60)

    # Strategy that trades only once
    class SingleTradeStrategy(BacktestEngine):
        def strategy(self, row):
            if len(self.position_book.trade_history.trades) == 0:  # Only first time
                long_position = self.position_book.get_position_by_tag("long")
                if not long_position and hasattr(row, 'close'):
                    self.position_book.open_long_position(
                        quantity=1.0,
                        open_price=row.close,
                        tag="long",
                        tp=row.close * 1.05,
                        sl=row.close * 0.95,
                        open_time=row.Index
                    )

    engine = SingleTradeStrategy(commission=0.001, portfolio_size=10000)
    engine.add_data_stream(data)
    engine.run()

    stats = engine.get_trading_stats()

    # With only 1 trade, Sharpe ratio should be 0
    assert stats['sharpe_ratio'] == 0.0
    assert stats['total_trades'] <= 1
