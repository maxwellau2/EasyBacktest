"""
Test the new metrics: annualized_return, calmar_ratio, average_win_pct, average_loss_pct
"""
import pytest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from easy_backtest.trade_history import TradeHistory


def test_annualized_return():
    """Test that annualized return is calculated and returned"""
    history = TradeHistory()

    # Add some winning trades over 1 year
    base_time = datetime(2024, 1, 1)
    for i in range(10):
        history.add_trade(
            tag=f"trade_{i}",
            mode="long",
            quantity=1.0,
            open_price=100.0,
            close_price=105.0,
            profit=50.0,  # $50 profit per trade
            pct=0.01,  # 1% return
            open_time=base_time + timedelta(days=i*30),
            close_time=base_time + timedelta(days=i*30, hours=1)
        )

    stats = history.get_stats(initial_portfolio=5000)

    # Check that annualized_return exists and is a number
    assert 'annualized_return' in stats
    assert isinstance(stats['annualized_return'], (int, float))
    assert not np.isnan(stats['annualized_return'])
    assert not np.isinf(stats['annualized_return'])


def test_calmar_ratio():
    """Test that Calmar ratio is calculated and returned"""
    history = TradeHistory()

    # Add trades with some drawdown
    base_time = datetime(2024, 1, 1)

    # Winning trades
    for i in range(3):
        history.add_trade(
            tag=f"win_{i}",
            mode="long",
            quantity=1.0,
            open_price=100.0,
            close_price=110.0,
            profit=100.0,
            pct=0.02,
            open_time=base_time + timedelta(days=i*10),
            close_time=base_time + timedelta(days=i*10, hours=1)
        )

    # Losing trade (creates drawdown)
    history.add_trade(
        tag="loss",
        mode="long",
        quantity=1.0,
        open_price=100.0,
        close_price=90.0,
        profit=-100.0,
        pct=-0.02,
        open_time=base_time + timedelta(days=30),
        close_time=base_time + timedelta(days=30, hours=1)
    )

    stats = history.get_stats(initial_portfolio=5000)

    # Check that calmar_ratio exists and is a number
    assert 'calmar_ratio' in stats
    assert isinstance(stats['calmar_ratio'], (int, float))
    assert not np.isnan(stats['calmar_ratio'])
    assert not np.isinf(stats['calmar_ratio'])


def test_average_win_loss_pct():
    """Test that average win/loss percentages are calculated"""
    history = TradeHistory()

    base_time = datetime(2024, 1, 1)

    # Add winning trades with 2% returns
    for i in range(3):
        history.add_trade(
            tag=f"win_{i}",
            mode="long",
            quantity=1.0,
            open_price=100.0,
            close_price=102.0,
            profit=100.0,
            pct=0.02,  # 2% return
            open_time=base_time + timedelta(days=i*5),
            close_time=base_time + timedelta(days=i*5, hours=1)
        )

    # Add losing trades with -1% returns
    for i in range(2):
        history.add_trade(
            tag=f"loss_{i}",
            mode="long",
            quantity=1.0,
            open_price=100.0,
            close_price=99.0,
            profit=-50.0,
            pct=-0.01,  # -1% return
            open_time=base_time + timedelta(days=15+i*5),
            close_time=base_time + timedelta(days=15+i*5, hours=1)
        )

    stats = history.get_stats(initial_portfolio=5000)

    # Check that percentage metrics exist
    assert 'average_win_pct' in stats
    assert 'average_loss_pct' in stats

    # Check they are numbers
    assert isinstance(stats['average_win_pct'], (int, float))
    assert isinstance(stats['average_loss_pct'], (int, float))

    # Average win should be around 2% (stored as 0.02, displayed as 2.0)
    assert abs(stats['average_win_pct'] - 2.0) < 0.1

    # Average loss should be around -1% (stored as -0.01, displayed as -1.0)
    assert abs(stats['average_loss_pct'] - (-1.0)) < 0.1


def test_profit_factor_no_losses():
    """Test that profit_factor handles all-winning trades gracefully"""
    history = TradeHistory()

    base_time = datetime(2024, 1, 1)

    # Add only winning trades
    for i in range(5):
        history.add_trade(
            tag=f"win_{i}",
            mode="long",
            quantity=1.0,
            open_price=100.0,
            close_price=105.0,
            profit=50.0,
            pct=0.01,
            open_time=base_time + timedelta(days=i*5),
            close_time=base_time + timedelta(days=i*5, hours=1)
        )

    stats = history.get_stats(initial_portfolio=5000)

    # Profit factor should be a large number, not infinity
    assert stats['profit_factor'] > 0
    assert stats['profit_factor'] < float('inf')
    assert not np.isinf(stats['profit_factor'])


def test_profit_factor_no_wins():
    """Test that profit_factor handles all-losing trades gracefully"""
    history = TradeHistory()

    base_time = datetime(2024, 1, 1)

    # Add only losing trades
    for i in range(5):
        history.add_trade(
            tag=f"loss_{i}",
            mode="long",
            quantity=1.0,
            open_price=100.0,
            close_price=95.0,
            profit=-50.0,
            pct=-0.01,
            open_time=base_time + timedelta(days=i*5),
            close_time=base_time + timedelta(days=i*5, hours=1)
        )

    stats = history.get_stats(initial_portfolio=5000)

    # Profit factor should be 0
    assert stats['profit_factor'] == 0.0


def test_calmar_ratio_no_drawdown():
    """Test that Calmar ratio handles case with no drawdown"""
    history = TradeHistory()

    base_time = datetime(2024, 1, 1)

    # Add only winning trades (no drawdown)
    for i in range(5):
        history.add_trade(
            tag=f"win_{i}",
            mode="long",
            quantity=1.0,
            open_price=100.0,
            close_price=105.0,
            profit=50.0,
            pct=0.01,
            open_time=base_time + timedelta(days=i*10),
            close_time=base_time + timedelta(days=i*10, hours=1)
        )

    stats = history.get_stats(initial_portfolio=5000)

    # With no drawdown (or very small), calmar ratio should be 0 or very large
    # We set it to 0 when max_drawdown is < 0.001%
    assert isinstance(stats['calmar_ratio'], (int, float))
    assert not np.isnan(stats['calmar_ratio'])


def test_all_new_metrics_in_empty_case():
    """Test that all new metrics are present even with no trades"""
    history = TradeHistory()
    stats = history.get_stats(initial_portfolio=10000)

    # All metrics should exist
    assert 'annualized_return' in stats
    assert 'calmar_ratio' in stats
    assert 'average_win_pct' in stats
    assert 'average_loss_pct' in stats

    # All should be 0.0
    assert stats['annualized_return'] == 0.0
    assert stats['calmar_ratio'] == 0.0
    assert stats['average_win_pct'] == 0.0
    assert stats['average_loss_pct'] == 0.0


def test_metrics_relationship():
    """Test the relationship between metrics"""
    history = TradeHistory()

    base_time = datetime(2024, 1, 1)

    # Add trades over 1 year
    history.add_trade("win1", "long", 1.0, 100, 110, 100, 0.02,
                     base_time, base_time + timedelta(hours=1))
    history.add_trade("loss1", "long", 1.0, 100, 95, -50, -0.01,
                     base_time + timedelta(days=30), base_time + timedelta(days=30, hours=1))
    history.add_trade("win2", "long", 1.0, 100, 105, 50, 0.01,
                     base_time + timedelta(days=60), base_time + timedelta(days=60, hours=1))

    stats = history.get_stats(initial_portfolio=5000)

    # Sharpe ratio should use annualized return in its calculation
    # If there's positive return and drawdown, Calmar should be calculable
    if stats['annualized_return'] > 0 and abs(stats['max_drawdown_percent']) > 0.001:
        expected_calmar = stats['annualized_return'] / (abs(stats['max_drawdown_percent']) / 100)
        assert abs(stats['calmar_ratio'] - expected_calmar) < 0.001

    # Average win % should be positive, average loss % should be negative
    if stats['average_win_pct'] != 0:
        assert stats['average_win_pct'] > 0
    if stats['average_loss_pct'] != 0:
        assert stats['average_loss_pct'] < 0
